# Huy Vector ESP32-C3

Custom Xiaozhi board configuration for:

- ESP32-C3
- INMP441 I2S microphone
- MAX98357A I2S amplifier
- SSD1306 128x64 I2C OLED
- Push-to-talk button on GPIO4

## Wiring

### INMP441
- VDD -> 3.3V
- GND -> GND
- SCK -> GPIO2
- WS -> GPIO1
- SD -> GPIO8
- L/R -> GND

### MAX98357A
- VIN -> 5V
- GND -> GND
- DIN -> GPIO3
- BCLK -> GPIO2
- LRC/WS -> GPIO1

### OLED SSD1306
- SDA -> GPIO21
- SCL -> GPIO20
- I2C address -> 0x3C

### Push-to-talk
- GPIO4 -> push button -> GND
- Firmware uses active-low input with internal pull-up.
- Hold button to listen; release button to stop listening.

## Radio configuration

- Bluetooth disabled.
- Wi-Fi provisioning uses hotspot mode, not BluFi.
- Wi-Fi maximum TX power is configured to 10 dBm.
- Wake word is not explicitly enabled; PTT is the physical listening trigger.
